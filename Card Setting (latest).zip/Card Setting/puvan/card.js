$(document).ready(function () {

$('.mobileNav').each(function () {
$(this).removeClass('active');
})

$('.nav-link') .each(function () {
$(this).removeClass('active');
})

$('.profile').each(function () {
$(this).addClass('active');
})

$('.profileMenu').addClass('active');
});
