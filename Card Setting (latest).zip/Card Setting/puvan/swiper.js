const swiper = new Swiper('.swiper-container', {
    // Optional parameters
    slidesPerView: 2,
    spaceBetween: 50,
    loop: true,
    effect: 'coverflow',
    coverflowEffect: {
        rotate: 30,
        slideShadows: false,
    },
    autoplay: {
        delay: 3000,
    },
    // If we need pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true
    },
    breakpoints: {
        // when window width is >= 320px
        320: {
            slidesPerView: 1,
            spaceBetween: 20
        },
        // when window width is >= 480px
        480: {
            slidesPerView: 1,
            spaceBetween: 30
        },
        // when window width is >= 640px
        640: {
            slidesPerView: 2,
            spaceBetween: 40
        }
    },

    //// Navigation arrows
    //navigation: {
    //    nextEl: '.swiper-button-next',
    //    prevEl: '.swiper-button-prev',
    //},

    // And if we need scrollbar
    scrollbar: {
        el: '.swiper-scrollbar',
    },
});

$('.swiper-slide').magnificPopup({
    delegate: 'a',
    type: 'image',
    closeOnContentClick: false,
    closeBtnInside: false,
    mainClass: 'mfp-with-zoom mfp-img-mobile',
    gallery: {
        enabled: true
    },
    zoom: {
        enabled: true,
        duration: 300,
        opener: function (element) {
            return element.find('img');
        }
    }

});
$('.btn-smt').on('click', function () {
    $('.login-form').attr('hidden', true);
    $('.title').removeClass('pt-lg-9');
    $('.title').addClass('pt-lg-5');
    $('.login-form-2').attr('hidden', false);
})