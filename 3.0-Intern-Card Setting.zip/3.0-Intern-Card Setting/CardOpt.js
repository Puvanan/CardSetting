$(document).ready(function () {
    $('.mobileNav').each(function () {
        $(this).removeClass('active');
    })
    $('.nav-link').each(function () {
        $(this).removeClass('active');
    })
    $('.profile').each(function () {
        $(this).addClass('active');
    });
    $('.profileMenu').addClass('active');

    $('#firstNext').on('click', function () {
        $('#secondPage').attr('hidden', false);
        $('#firstPage').attr('hidden', true);
        $('#thirdPage').attr('hidden', true);
        $('#fourthPage').attr('hidden', true);
    });
    $('.pac').on('click', function () {
        Swal.fire(
            'OTP is Sent!',
            'OTP sent to your phone number 012 - * * * * 123',
            'success'
        )
    })
    $('#secondNext').on('click', function () {
        // Swal.fire(
        //     'Success',
        //     'Your Information Successfully Saved',
        //     'success'
        // )
        $('#thirdPage').attr('hidden', false);
        $('#secondPage').attr('hidden', true);
        $('#firstPage').attr('hidden', true);
        $('#fourthPage').attr('hidden', true);
    })

    $('#fourthNext').on('click', function () {
        $('#fourthPage').attr('hidden', false);
        $('#thirdPage').attr('hidden', true);
        $('#secondPage').attr('hidden', true);
        $('#firstPage').attr('hidden', true);
    })
});


  // Edit

$(document).ready(function () {
  $('#secondNext').hide();
  $("#thirdNext").click(function () {
    $(this).hide();
    $('#secondNext').show();
    // $('#reset-btn').show();
    $("input").prop('disabled', false);
    $("select").prop('disabled', false);
    $('#cancel-btn').click(function () {
      location.reload();
    });

    if ($('#radio-1').is(':checked')) {
      $('#selectBranch').prop('disabled', true);
    }
    
  });
});

function disableSelect() {
  $('#selectBranch').prop('disabled', true);
}

function enableSelect() {
  $('#selectBranch').prop('disabled', false);
}

$(document).on('click', '#secondNext', function () {
  Swal.fire({
    title: 'Do you want to save the changes?',
    showCancelButton: true,
    confirmButtonText: 'Save',
    allowOutsideClick: false,
    confirmButtonColor: '#D14655',
    cancelButtonColor: '#4E5E68',
    customClass: {
      title: 'alertFontStyle'
    }
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        title: 'Your information is update',
        icon: 'success',
        iconColor: '#3AA08A',
        confirmButtonColor: '#D14655',
        customClass: {
          title: 'alertFontStyle'
        }
      }).then(function () {
        $('#secondPage').submit();
        // nextForm();
      });
    }
  })


});