const nxtBtn = document.querySelector('#submitBtn');
const form1 = document.querySelector('#form1');
const form2 = document.querySelector('#form2');
const form3 = document.querySelector('#form3');
const form4 = document.querySelector('#form4');


const icon1 = document.querySelector('#icon1');
const icon2 = document.querySelector('#icon2');
const icon3 = document.querySelector('#icon3');
const icon4 = document.querySelector('#icon4');


var viewId = 1;
function nextForm() {
  console.log("hellonext");
  viewId = viewId + 1;
  progressBar();
  displayForms();
  console.log(viewId);
}

function prevForm() {
  console.log("helloprev");
  viewId = viewId - 1;
  console.log(viewId);
  progressBar1();
  displayForms();
  var otpCard = document.getElementById("otpCard");
  otpCard.classList.add('d-none');

  $('#submit-btn').hide();
    $('#modify-btn').show();
    $('#reset-btn').show();
    $("input").prop('disabled', true);
    $("select").prop('disabled', true);
    $('#cancel-btn').click(function () {
      location.reload();
    });

    if ($('#radio-1').is(':checked')) {
      $('#selectBranch').prop('disabled', true);
    }
    
}

function progressBar1() {

  if (viewId === 1) {
    icon2.classList.add('active');
    icon2.classList.remove('active');
    icon3.classList.remove('active');
    icon4.classList.remove('active');
  }

  if (viewId === 2) {
    icon2.classList.add('active');
    icon3.classList.remove('active');
    icon4.classList.remove('active');
  }

  if (viewId === 3) {
    icon3.classList.add('active');
    icon4.classList.remove('active');
  }

  if (viewId === 4) {
    icon4.classList.add('active');
    nxtBtn.innerHTML = "Submit"
  }

  if (viewId > 4) {
    icon2.classList.remove('active');
    icon3.classList.remove('active');
    icon4.classList.remove('active');
  }
}

function progressBar() {

  if (viewId === 2) {
    icon2.classList.add('active');
  }

  if (viewId === 3) {
    icon3.classList.add('active');
  }

  if (viewId === 4) {
    icon4.classList.add('active');
    nxtBtn.innerHTML = "Submit"
  }

  if (viewId > 4) {
    icon2.classList.remove('active');
    icon3.classList.remove('active');
    icon4.classList.remove('active');
  }
}

function displayForms() {

  if (viewId > 4) {
    viewId = 1;
  }

  if (viewId === 1) {
    form1.style.display = 'block';
    form2.style.display = 'none';
    form3.style.display = 'none';
    form4.style.display = 'none';
  }

  else if (viewId === 2) {
    form1.style.display = 'none';
    form2.style.display = 'block';
    form3.style.display = 'none';
    form4.style.display = 'none';
  }

  else if (viewId === 3) {
    form1.style.display = 'none';
    form2.style.display = 'none';
    form3.style.display = 'block';
    form4.style.display = 'none';
  }

  else if (viewId === 4) {
    form1.style.display = 'none';
    form2.style.display = 'none';
    form3.style.display = 'none';
    form4.style.display = 'block';
  }
}


// Edit

$(document).ready(function () {
  $('#submit-btn').hide();
  $("#modify-btn").click(function () {
    $(this).hide();
    $('#submit-btn').show();
    $('#reset-btn').show();
    $("input").prop('disabled', false);
    $("select").prop('disabled', false);
    $('#cancel-btn').click(function () {
      location.reload();
    });

    if ($('#radio-1').is(':checked')) {
      $('#selectBranch').prop('disabled', true);
    }
    
  });
});

function disableSelect() {
  $('#selectBranch').prop('disabled', true);
}

function enableSelect() {
  $('#selectBranch').prop('disabled', false);
}

$(document).on('click', '#submit-btn', function () {
  Swal.fire({
    title: 'Do you want to save the changes?',
    showCancelButton: true,
    confirmButtonText: 'Save',
    allowOutsideClick: false,
    confirmButtonColor: '#D14655',
    cancelButtonColor: '#4E5E68',
    customClass: {
      title: 'alertFontStyle'
    }
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        title: 'Your information is update',
        icon: 'success',
        iconColor: '#3AA08A',
        confirmButtonColor: '#D14655',
        customClass: {
          title: 'alertFontStyle'
        }
      }).then(function () {
        $('#form2').submit();
        nextForm();
      });
    }
  })
});

// function fun(){
//     document.getElementById("myForm").reset();
//   } 



// OTP

function popUpOTP() {
  var otpCard = document.getElementById("otpCard");
  otpCard.classList.remove('d-none');
}

var app = new Vue({
  el: '#app',
  methods: {
    inputenter(id) {

      const inputs = document.querySelectorAll('#otp > *[id]');
      for (let i = 0; i < inputs.length; i++) {
        inputs[i].addEventListener('keydown', function (event) {
          if (event.key === "Backspace") {
            inputs[i].value = ''; if (i !== 0) inputs[i - 1].focus();
          }
          else {
            if (i === inputs.length - 1 && inputs[i].value !== '') {
              return true;
            }
            else if (event.keyCode > 47 && event.keyCode < 58) {
              inputs[i].value = event.key;
              if (i !== inputs.length - 1) inputs[i + 1].focus(); event.preventDefault();
            }
            else if (event.keyCode > 64 && event.keyCode < 91) {
              inputs[i].value = String.fromCharCode(event.keyCode);
              if (i !== inputs.length - 1) inputs[i + 1].focus(); event.preventDefault();
            }
          }
        });
      }
    }
  }
});

